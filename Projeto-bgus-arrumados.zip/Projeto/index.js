const express = require('express');
const app = express();
const path = require('path');
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

// Configuração do caminho para o diretório 'public'
const publicPath = path.join(__dirname, 'public');

app.use(express.static(publicPath));
app.use(express.urlencoded({ extended: true }));

// Rota padrão para abrir index.html ao acessar localhost:3006
app.get('/', (req, res) => {
  res.sendFile('index.html', { root: path.join(__dirname, 'views') });
});

// Rota para servir o arquivo CSS
app.get('/style.css', (req, res) => {
  res.sendFile('style.css', { root: path.join(__dirname, 'css') });
});

// Rota para cadastro de usuários
app.post('/register', async (req, res) => {
  const { signupName, signupEmail, signupPassword } = req.body;

  try {
    // Criptografar a senha antes de salvar no banco de dados
    const hashedPassword = await bcrypt.hash(signupPassword, 10); // Nível de salto (salt) 10 é um valor comum

    const newUser = await prisma.user.create({
      data: {
        username: signupName,
        email: signupEmail,
        password: hashedPassword, // Salvar a senha criptografada no banco de dados
      },
    });

    res.send(`Usuário ${newUser.username} cadastrado com sucesso!`);
  } catch (error) {
    res.send(`Erro ao cadastrar o usuário: ${error.message}`);
  }
});

// Rota para autenticar usuários (login)
app.post('/login', async (req, res) => {
  const { loginEmail, loginPassword } = req.body;

  try {
    const user = await prisma.user.findUnique({
      where: {
        email: loginEmail,
      },
    });

    if (!user || !(await bcrypt.compare(loginPassword, user.password))) {
      res.send('Credenciais inválidas. Tente novamente.');
    } else {
      res.redirect('/views/terminal.html');
    }
  } catch (error) {
    res.send(`Erro ao fazer login: ${error.message}`);
  }
});

const PORT = 3006; // Defina a porta desejada
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
