const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');
let id = 1; // Você pode usar o ID apropriadamente.

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

$(document).ready(function() {
    // Manipulação do formulário de login
    $('#loginButton').on('click', function(e) {
      e.preventDefault();
  
      const loginEmail = $('#loginEmail').val();
      const loginPassword = $('#loginPassword').val();
  
      $.post('/login', { loginEmail, loginPassword }, function(response) {
        if (response.startsWith('Erro')) {
          alert(response);
        } else {
          window.location.replace('terminal.html');
        }
      });
    });
  
    // Manipulação do formulário de cadastro
    $('#registerButton').on('click', function(e) {
      e.preventDefault();
  
      const signupName = $('#signupName').val();
      const signupEmail = $('#signupEmail').val();
      const signupPassword = $('#signupPassword').val();
  
      $.post('/register', { signupName, signupEmail, signupPassword }, function(response) {
        alert(response);
      });
    });
  });
  