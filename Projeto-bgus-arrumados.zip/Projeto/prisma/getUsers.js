const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function getUsers() {
  try {
    const users = await prisma.user.findMany();
    console.log('Usuários cadastrados:', users);
  } catch (error) {
    console.error('Erro ao buscar os usuários:', error);
  } finally {
    await prisma.$disconnect();
  }
}

getUsers();
